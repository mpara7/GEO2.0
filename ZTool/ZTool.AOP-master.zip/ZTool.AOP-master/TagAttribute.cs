﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTool.AOP;

/// <summary>
/// 附加方法的签名应当为 class -> void
/// </summary>
[AttributeUsage(AttributeTargets.Method, AllowMultiple = true, Inherited = false)]
public class TagAttribute : Attribute
{
    public string Token { get; set; }
    public TagAttribute(string token)
    {
        Token = token;
    }
}

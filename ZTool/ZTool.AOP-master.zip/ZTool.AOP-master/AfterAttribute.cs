﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTool.AOP
{
    /// <summary>
    /// 附加方法的签名应当为 class -> class 基础函数可能无法修改
    /// 如果是 void->void 由于不对调用栈堆产生影响 可以随意调用
    /// 如果以后可以 了解本地变量的赋值 可以做得更加复杂
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true, Inherited = false)]
    public class AfterAttribute : Attribute
    {

        public string Token { get; set; }
        public AfterAttribute(string token)
        {
            Token = token;
        }
    }
}

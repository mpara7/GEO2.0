﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTool.AOP;

public class AOPBuilder
{
    /// <summary>
    /// 创建的类型可以注册到Container中使用
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <returns></returns>
    public Type BuildType<T>()
    {
        return null;
    }

}

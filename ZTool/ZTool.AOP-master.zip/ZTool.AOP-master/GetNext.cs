﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTool.AOP;

public abstract class GetNext
{
    public abstract void DoNext();
    public abstract void End();
}
